﻿namespace Event
{
    partial class login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labelmassage = new System.Windows.Forms.Label();
            this.labelmassage1 = new System.Windows.Forms.Label();
            this.labelpass = new System.Windows.Forms.Label();
            this.labelusername = new System.Windows.Forms.Label();
            this.buttonsignup = new System.Windows.Forms.Button();
            this.buttonforgotpass = new System.Windows.Forms.Button();
            this.labelemail = new System.Windows.Forms.Label();
            this.textboxusername = new System.Windows.Forms.TextBox();
            this.textBoxpass = new System.Windows.Forms.TextBox();
            this.textBoxemail = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.buttonlogin = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // labelmassage
            // 
            this.labelmassage.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmassage.Location = new System.Drawing.Point(11, 613);
            this.labelmassage.Name = "labelmassage";
            this.labelmassage.Size = new System.Drawing.Size(232, 22);
            this.labelmassage.TabIndex = 0;
            this.labelmassage.Text = "Don\'t have an account?";
            this.labelmassage.Click += new System.EventHandler(this.labelmassage_Click);
            // 
            // labelmassage1
            // 
            this.labelmassage1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.labelmassage1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelmassage1.ForeColor = System.Drawing.Color.Navy;
            this.labelmassage1.Location = new System.Drawing.Point(63, 111);
            this.labelmassage1.Name = "labelmassage1";
            this.labelmassage1.Size = new System.Drawing.Size(296, 40);
            this.labelmassage1.TabIndex = 2;
            this.labelmassage1.Text = "Hello! Let\'s get started";
            // 
            // labelpass
            // 
            this.labelpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelpass.Location = new System.Drawing.Point(32, 367);
            this.labelpass.Name = "labelpass";
            this.labelpass.Size = new System.Drawing.Size(101, 28);
            this.labelpass.TabIndex = 4;
            this.labelpass.Text = "Password :";
            this.labelpass.Click += new System.EventHandler(this.label5_Click);
            // 
            // labelusername
            // 
            this.labelusername.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelusername.Location = new System.Drawing.Point(29, 200);
            this.labelusername.Name = "labelusername";
            this.labelusername.Size = new System.Drawing.Size(134, 31);
            this.labelusername.TabIndex = 5;
            this.labelusername.Text = "User Name :";
            this.labelusername.Click += new System.EventHandler(this.label6_Click);
            // 
            // buttonsignup
            // 
            this.buttonsignup.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.buttonsignup.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonsignup.ForeColor = System.Drawing.Color.White;
            this.buttonsignup.Location = new System.Drawing.Point(249, 607);
            this.buttonsignup.Name = "buttonsignup";
            this.buttonsignup.Size = new System.Drawing.Size(85, 33);
            this.buttonsignup.TabIndex = 6;
            this.buttonsignup.Text = "Sign up";
            this.buttonsignup.UseVisualStyleBackColor = false;
            // 
            // buttonforgotpass
            // 
            this.buttonforgotpass.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.buttonforgotpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonforgotpass.ForeColor = System.Drawing.SystemColors.Info;
            this.buttonforgotpass.Location = new System.Drawing.Point(180, 441);
            this.buttonforgotpass.Name = "buttonforgotpass";
            this.buttonforgotpass.Size = new System.Drawing.Size(145, 33);
            this.buttonforgotpass.TabIndex = 8;
            this.buttonforgotpass.Text = "Forgot Password ";
            this.buttonforgotpass.UseVisualStyleBackColor = false;
            // 
            // labelemail
            // 
            this.labelemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelemail.Location = new System.Drawing.Point(29, 284);
            this.labelemail.Name = "labelemail";
            this.labelemail.Size = new System.Drawing.Size(134, 31);
            this.labelemail.TabIndex = 9;
            this.labelemail.Text = "Email :";
            // 
            // textboxusername
            // 
            this.textboxusername.Location = new System.Drawing.Point(32, 234);
            this.textboxusername.Name = "textboxusername";
            this.textboxusername.Size = new System.Drawing.Size(290, 22);
            this.textboxusername.TabIndex = 10;
            // 
            // textBoxpass
            // 
            this.textBoxpass.Location = new System.Drawing.Point(35, 398);
            this.textBoxpass.Name = "textBoxpass";
            this.textBoxpass.Size = new System.Drawing.Size(290, 22);
            this.textBoxpass.TabIndex = 11;
            // 
            // textBoxemail
            // 
            this.textBoxemail.Location = new System.Drawing.Point(32, 318);
            this.textBoxemail.Name = "textBoxemail";
            this.textBoxemail.Size = new System.Drawing.Size(290, 22);
            this.textBoxemail.TabIndex = 12;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Event.Properties.Resources.login;
            this.pictureBox1.Location = new System.Drawing.Point(416, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(620, 759);
            this.pictureBox1.TabIndex = 13;
            this.pictureBox1.TabStop = false;
            // 
            // buttonlogin
            // 
            this.buttonlogin.BackColor = System.Drawing.Color.DarkSlateBlue;
            this.buttonlogin.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonlogin.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.buttonlogin.Location = new System.Drawing.Point(68, 522);
            this.buttonlogin.Name = "buttonlogin";
            this.buttonlogin.Size = new System.Drawing.Size(134, 42);
            this.buttonlogin.TabIndex = 7;
            this.buttonlogin.Text = "Log in ";
            this.buttonlogin.UseVisualStyleBackColor = false;
            // 
            // login
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(1029, 741);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.textBoxemail);
            this.Controls.Add(this.textBoxpass);
            this.Controls.Add(this.textboxusername);
            this.Controls.Add(this.labelemail);
            this.Controls.Add(this.buttonforgotpass);
            this.Controls.Add(this.buttonlogin);
            this.Controls.Add(this.buttonsignup);
            this.Controls.Add(this.labelusername);
            this.Controls.Add(this.labelpass);
            this.Controls.Add(this.labelmassage1);
            this.Controls.Add(this.labelmassage);
            this.Name = "login";
            this.Text = "login";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labelmassage;
        private System.Windows.Forms.Label labelmassage1;
        private System.Windows.Forms.Label labelpass;
        private System.Windows.Forms.Label labelusername;
        private System.Windows.Forms.Button buttonsignup;
        private System.Windows.Forms.Button buttonforgotpass;
        private System.Windows.Forms.Label labelemail;
        private System.Windows.Forms.TextBox textboxusername;
        private System.Windows.Forms.TextBox textBoxpass;
        private System.Windows.Forms.TextBox textBoxemail;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button buttonlogin;
    }
}