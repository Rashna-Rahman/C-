﻿namespace Event
{
    partial class forgotpassword
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.labelname = new System.Windows.Forms.Label();
            this.labelpass = new System.Windows.Forms.Label();
            this.labelemail = new System.Windows.Forms.Label();
            this.textBoxname = new System.Windows.Forms.TextBox();
            this.textBoxnewpass = new System.Windows.Forms.TextBox();
            this.textBoxemail = new System.Windows.Forms.TextBox();
            this.buttonresetpass = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Event.Properties.Resources.passforgot;
            this.pictureBox1.Location = new System.Drawing.Point(337, 1);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(449, 363);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // labelname
            // 
            this.labelname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelname.Location = new System.Drawing.Point(26, 47);
            this.labelname.Name = "labelname";
            this.labelname.Size = new System.Drawing.Size(111, 30);
            this.labelname.TabIndex = 1;
            this.labelname.Text = "User Name:";
            // 
            // labelpass
            // 
            this.labelpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelpass.Location = new System.Drawing.Point(26, 217);
            this.labelpass.Name = "labelpass";
            this.labelpass.Size = new System.Drawing.Size(244, 30);
            this.labelpass.TabIndex = 2;
            this.labelpass.Text = "Confirm New Password :";
            // 
            // labelemail
            // 
            this.labelemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelemail.Location = new System.Drawing.Point(26, 135);
            this.labelemail.Name = "labelemail";
            this.labelemail.Size = new System.Drawing.Size(111, 30);
            this.labelemail.TabIndex = 3;
            this.labelemail.Text = "Email :";
            // 
            // textBoxname
            // 
            this.textBoxname.Location = new System.Drawing.Point(29, 81);
            this.textBoxname.Name = "textBoxname";
            this.textBoxname.Size = new System.Drawing.Size(241, 22);
            this.textBoxname.TabIndex = 4;
            // 
            // textBoxnewpass
            // 
            this.textBoxnewpass.Location = new System.Drawing.Point(25, 250);
            this.textBoxnewpass.Name = "textBoxnewpass";
            this.textBoxnewpass.Size = new System.Drawing.Size(241, 22);
            this.textBoxnewpass.TabIndex = 5;
            // 
            // textBoxemail
            // 
            this.textBoxemail.Location = new System.Drawing.Point(25, 168);
            this.textBoxemail.Name = "textBoxemail";
            this.textBoxemail.Size = new System.Drawing.Size(241, 22);
            this.textBoxemail.TabIndex = 6;
            // 
            // buttonresetpass
            // 
            this.buttonresetpass.BackColor = System.Drawing.Color.DarkRed;
            this.buttonresetpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonresetpass.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttonresetpass.Location = new System.Drawing.Point(25, 297);
            this.buttonresetpass.Name = "buttonresetpass";
            this.buttonresetpass.Size = new System.Drawing.Size(273, 34);
            this.buttonresetpass.TabIndex = 7;
            this.buttonresetpass.Text = "Reset My Password";
            this.buttonresetpass.UseVisualStyleBackColor = false;
            // 
            // forgotpassword
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlLight;
            this.ClientSize = new System.Drawing.Size(793, 366);
            this.Controls.Add(this.buttonresetpass);
            this.Controls.Add(this.textBoxemail);
            this.Controls.Add(this.textBoxnewpass);
            this.Controls.Add(this.textBoxname);
            this.Controls.Add(this.labelemail);
            this.Controls.Add(this.labelpass);
            this.Controls.Add(this.labelname);
            this.Controls.Add(this.pictureBox1);
            this.Name = "forgotpassword";
            this.Text = "forgotpassword";
            this.Load += new System.EventHandler(this.forgotpassword_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label labelname;
        private System.Windows.Forms.Label labelpass;
        private System.Windows.Forms.Label labelemail;
        private System.Windows.Forms.TextBox textBoxname;
        private System.Windows.Forms.TextBox textBoxnewpass;
        private System.Windows.Forms.TextBox textBoxemail;
        private System.Windows.Forms.Button buttonresetpass;
    }
}