﻿namespace Event
{
    partial class registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.labeldesignation = new System.Windows.Forms.Label();
            this.radioButtonmale = new System.Windows.Forms.RadioButton();
            this.radioButtonemployee = new System.Windows.Forms.RadioButton();
            this.radioButtonmanager = new System.Windows.Forms.RadioButton();
            this.radioButtonfemale = new System.Windows.Forms.RadioButton();
            this.textBoxemail = new System.Windows.Forms.TextBox();
            this.textBoxpass = new System.Windows.Forms.TextBox();
            this.textBoxconfirmpass = new System.Windows.Forms.TextBox();
            this.textBoxname = new System.Windows.Forms.TextBox();
            this.labelgender = new System.Windows.Forms.Label();
            this.labelconfirmpass = new System.Windows.Forms.Label();
            this.labelpass = new System.Windows.Forms.Label();
            this.buttondone = new System.Windows.Forms.Button();
            this.labelemail = new System.Windows.Forms.Label();
            this.labelname = new System.Windows.Forms.Label();
            this.labelreg = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // labeldesignation
            // 
            this.labeldesignation.BackColor = System.Drawing.Color.Transparent;
            this.labeldesignation.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labeldesignation.Location = new System.Drawing.Point(11, 488);
            this.labeldesignation.Name = "labeldesignation";
            this.labeldesignation.Size = new System.Drawing.Size(131, 31);
            this.labeldesignation.TabIndex = 51;
            this.labeldesignation.Text = "Designation :";
            // 
            // radioButtonmale
            // 
            this.radioButtonmale.AutoSize = true;
            this.radioButtonmale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonmale.Location = new System.Drawing.Point(293, 432);
            this.radioButtonmale.Name = "radioButtonmale";
            this.radioButtonmale.Size = new System.Drawing.Size(65, 22);
            this.radioButtonmale.TabIndex = 50;
            this.radioButtonmale.TabStop = true;
            this.radioButtonmale.Text = "Male";
            this.radioButtonmale.UseVisualStyleBackColor = true;
            // 
            // radioButtonemployee
            // 
            this.radioButtonemployee.AutoSize = true;
            this.radioButtonemployee.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonemployee.Location = new System.Drawing.Point(168, 488);
            this.radioButtonemployee.Name = "radioButtonemployee";
            this.radioButtonemployee.Size = new System.Drawing.Size(103, 22);
            this.radioButtonemployee.TabIndex = 49;
            this.radioButtonemployee.TabStop = true;
            this.radioButtonemployee.Text = "Employee";
            this.radioButtonemployee.UseVisualStyleBackColor = true;
            // 
            // radioButtonmanager
            // 
            this.radioButtonmanager.AutoSize = true;
            this.radioButtonmanager.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonmanager.Location = new System.Drawing.Point(293, 488);
            this.radioButtonmanager.Name = "radioButtonmanager";
            this.radioButtonmanager.Size = new System.Drawing.Size(94, 22);
            this.radioButtonmanager.TabIndex = 48;
            this.radioButtonmanager.TabStop = true;
            this.radioButtonmanager.Text = "Manager";
            this.radioButtonmanager.UseVisualStyleBackColor = true;
            // 
            // radioButtonfemale
            // 
            this.radioButtonfemale.AutoSize = true;
            this.radioButtonfemale.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radioButtonfemale.Location = new System.Drawing.Point(168, 432);
            this.radioButtonfemale.Name = "radioButtonfemale";
            this.radioButtonfemale.Size = new System.Drawing.Size(84, 22);
            this.radioButtonfemale.TabIndex = 47;
            this.radioButtonfemale.TabStop = true;
            this.radioButtonfemale.Text = "Female";
            this.radioButtonfemale.UseVisualStyleBackColor = true;
            // 
            // textBoxemail
            // 
            this.textBoxemail.BackColor = System.Drawing.SystemColors.HighlightText;
            this.textBoxemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxemail.ForeColor = System.Drawing.SystemColors.Info;
            this.textBoxemail.Location = new System.Drawing.Point(176, 225);
            this.textBoxemail.Name = "textBoxemail";
            this.textBoxemail.Size = new System.Drawing.Size(232, 24);
            this.textBoxemail.TabIndex = 46;
            // 
            // textBoxpass
            // 
            this.textBoxpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxpass.Location = new System.Drawing.Point(176, 291);
            this.textBoxpass.Name = "textBoxpass";
            this.textBoxpass.Size = new System.Drawing.Size(232, 24);
            this.textBoxpass.TabIndex = 45;
            // 
            // textBoxconfirmpass
            // 
            this.textBoxconfirmpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxconfirmpass.Location = new System.Drawing.Point(176, 358);
            this.textBoxconfirmpass.Name = "textBoxconfirmpass";
            this.textBoxconfirmpass.Size = new System.Drawing.Size(232, 24);
            this.textBoxconfirmpass.TabIndex = 44;
            // 
            // textBoxname
            // 
            this.textBoxname.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxname.Location = new System.Drawing.Point(176, 161);
            this.textBoxname.Name = "textBoxname";
            this.textBoxname.Size = new System.Drawing.Size(232, 24);
            this.textBoxname.TabIndex = 43;
            // 
            // labelgender
            // 
            this.labelgender.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelgender.Location = new System.Drawing.Point(28, 429);
            this.labelgender.Name = "labelgender";
            this.labelgender.Size = new System.Drawing.Size(101, 23);
            this.labelgender.TabIndex = 42;
            this.labelgender.Text = "Gender :";
            // 
            // labelconfirmpass
            // 
            this.labelconfirmpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelconfirmpass.Location = new System.Drawing.Point(11, 358);
            this.labelconfirmpass.Name = "labelconfirmpass";
            this.labelconfirmpass.Size = new System.Drawing.Size(164, 22);
            this.labelconfirmpass.TabIndex = 41;
            this.labelconfirmpass.Text = "Confirm Pass:";
            // 
            // labelpass
            // 
            this.labelpass.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelpass.Location = new System.Drawing.Point(28, 291);
            this.labelpass.Name = "labelpass";
            this.labelpass.Size = new System.Drawing.Size(133, 22);
            this.labelpass.TabIndex = 40;
            this.labelpass.Text = "Password :";
            // 
            // buttondone
            // 
            this.buttondone.BackColor = System.Drawing.Color.DarkRed;
            this.buttondone.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttondone.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.buttondone.Location = new System.Drawing.Point(122, 590);
            this.buttondone.Name = "buttondone";
            this.buttondone.Size = new System.Drawing.Size(149, 42);
            this.buttondone.TabIndex = 39;
            this.buttondone.Text = "Done";
            this.buttondone.UseVisualStyleBackColor = false;
            // 
            // labelemail
            // 
            this.labelemail.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelemail.Location = new System.Drawing.Point(58, 225);
            this.labelemail.Name = "labelemail";
            this.labelemail.Size = new System.Drawing.Size(101, 22);
            this.labelemail.TabIndex = 38;
            this.labelemail.Text = "Email :";
            // 
            // labelname
            // 
            this.labelname.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelname.Location = new System.Drawing.Point(58, 163);
            this.labelname.Name = "labelname";
            this.labelname.Size = new System.Drawing.Size(101, 23);
            this.labelname.TabIndex = 37;
            this.labelname.Text = "Name :";
            // 
            // labelreg
            // 
            this.labelreg.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.2F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelreg.ForeColor = System.Drawing.Color.DarkRed;
            this.labelreg.Location = new System.Drawing.Point(134, 63);
            this.labelreg.Name = "labelreg";
            this.labelreg.Size = new System.Drawing.Size(179, 48);
            this.labelreg.TabIndex = 36;
            this.labelreg.Text = "Register";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Event.Properties.Resources.regf1;
            this.pictureBox1.Location = new System.Drawing.Point(433, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(600, 759);
            this.pictureBox1.TabIndex = 52;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // registration
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PeachPuff;
            this.ClientSize = new System.Drawing.Size(1028, 763);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.labeldesignation);
            this.Controls.Add(this.radioButtonmale);
            this.Controls.Add(this.radioButtonemployee);
            this.Controls.Add(this.radioButtonmanager);
            this.Controls.Add(this.radioButtonfemale);
            this.Controls.Add(this.textBoxemail);
            this.Controls.Add(this.textBoxpass);
            this.Controls.Add(this.textBoxconfirmpass);
            this.Controls.Add(this.textBoxname);
            this.Controls.Add(this.labelgender);
            this.Controls.Add(this.labelconfirmpass);
            this.Controls.Add(this.labelpass);
            this.Controls.Add(this.buttondone);
            this.Controls.Add(this.labelemail);
            this.Controls.Add(this.labelname);
            this.Controls.Add(this.labelreg);
            this.Name = "registration";
            this.Text = "registration";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label labeldesignation;
        private System.Windows.Forms.RadioButton radioButtonmale;
        private System.Windows.Forms.RadioButton radioButtonemployee;
        private System.Windows.Forms.RadioButton radioButtonmanager;
        private System.Windows.Forms.RadioButton radioButtonfemale;
        private System.Windows.Forms.TextBox textBoxemail;
        private System.Windows.Forms.TextBox textBoxpass;
        private System.Windows.Forms.TextBox textBoxconfirmpass;
        private System.Windows.Forms.TextBox textBoxname;
        private System.Windows.Forms.Label labelgender;
        private System.Windows.Forms.Label labelconfirmpass;
        private System.Windows.Forms.Label labelpass;
        private System.Windows.Forms.Button buttondone;
        private System.Windows.Forms.Label labelemail;
        private System.Windows.Forms.Label labelname;
        private System.Windows.Forms.Label labelreg;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}